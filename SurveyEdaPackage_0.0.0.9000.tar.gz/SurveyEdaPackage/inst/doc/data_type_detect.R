## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=FALSE, results='hide', message=FALSE, warning=FALSE----------
library(SurveyEdaPackage)

## ----eval = FALSE-------------------------------------------------------------
#  summary(data_type_detect(basic_test_data))
#  generic_characteristics <- Data_Describe(basic_test_data)
#  print(generic_characteristics)
#  plot(generic_characteristics)
#  x <- Numeric_Uni_EDA(basic_test_data)
#  summary(x)
#  plot(x)
#  x <- Categorical_Uni_EDA(basic_test_data)
#  print(x)
#  plot(x)
#  x <- NLP_Uni_EDA(basic_test_data)
#  plot(x)

## ---- results='asis'----------------------------------------------------------
summary(data_type_detect(basic_test_data))

## ----warning=FALSE, fig.dim = c(7.5,7.5), results='asis'----------------------
generic_characteristics <- Data_Describe(basic_test_data)
print(generic_characteristics)
plot(generic_characteristics)

## ---- fig.dim = c(7.5,7.5), warning=FALSE, results='asis'---------------------
x <- Numeric_Uni_EDA(basic_test_data)
summary(x)
plot(x)

## ----fig.dim = c(7.5,7.5), warning=FALSE, results='asis'----------------------
x <- Categorical_Uni_EDA(basic_test_data)
print(x)
plot(x)

## ---- fig.dim= c(7.5,12), warning=FALSE---------------------------------------
x <- NLP_Column_Analysis(natural_language_column$reviews, 'Reviews')
plot(x)

