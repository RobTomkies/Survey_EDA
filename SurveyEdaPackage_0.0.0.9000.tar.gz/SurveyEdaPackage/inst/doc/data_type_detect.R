## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(SurveyEdaPackage)

## -----------------------------------------------------------------------------
summary(data_type_detect(basic_test_data))
print(data_type_detect(basic_test_data))

