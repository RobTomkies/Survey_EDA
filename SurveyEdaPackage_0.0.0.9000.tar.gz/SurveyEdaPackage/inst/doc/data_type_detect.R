## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=FALSE, results='hide', message=FALSE, warning=FALSE----------
library(SurveyEdaPackage)

## -----------------------------------------------------------------------------
summary(data_type_detect(basic_test_data))

## ----warning=FALSE, fig.dim = c(7.5,7.5), results='asis'----------------------
generic_characteristics <- Data_Describe(basic_test_data)
print(generic_characteristics)
plot(generic_characteristics)

## ----fig.height = 7.5, fig.width = 7.5, warning=FALSE, results='asis'---------
x <- Numeric_Uni_EDA(basic_test_data)
summary(x)
plot(x)

## ----fig.dim = c(7.5,7.5), warning=FALSE, results='asis'----------------------
x <- Categorical_Uni_EDA(basic_test_data)
print(x)
plot(x)

## -----------------------------------------------------------------------------
summary(data_type_detect(basic_test_data))
print(data_type_detect(basic_test_data))

## -----------------------------------------------------------------------------
x <- Data_Describe(basic_test_data)
print(x)
plot(x)

