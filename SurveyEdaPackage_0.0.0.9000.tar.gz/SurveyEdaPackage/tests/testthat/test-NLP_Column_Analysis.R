test_that("Input Warnings are correct unique to function",{
  expect_silent(NLP_Column_Analysis(basic_test_data$reviews, 'Reviews'))
  expect_error(NLP_Column_Analysis(basic_test_data$reviews,list(c(1,2,3))), 'column name must be a string')
  expect_error(NLP_Column_Analysis(list(1,2,3,list(2,3,4)),'Reviews'), 'Input data must be a vector of strings, one row for each response')
})
