## usethis namespace: start
#' @useDynLib SurveyEdaPackage, .registration=TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
