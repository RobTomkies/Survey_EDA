#' @export
NLP_Uni_EDA <- function(dataset,
                        detect = T,
                        NLP.force = c(),
                        ignore.columns = c(),
                        analyse_split_answers = T,
                        alternate.nas = list()){

  #dataset dimensions
  original_nrow <- nrow(dataset)
  original_ncol <- ncol(dataset)

  updated_data <- SurveyEdaPackage::data_type_detect(dataset,
                                                     ordinal_force = ordinal.force,
                                                     nominal_force = nominal.force,
                                                     alternate_nas = alternate.nas,
                                                     preserve_nonconform = analyse_split_answers)

  drop_vector <- column_recog_vector('ignore.columns', ignore.columns, dataset)

  if(analyse_split_answers == T){
    split_out_columns <- names(updated_data$data)[!(names(updated_data$data) %in% updated_data$converted_type$data_field)]
    NLP_names_standard <- updated_data$converted_type$data_field[updated_data$converted_type$data_type == 'Natural Language']
    NLP_names <- c(NLP_names_standard, split_out_columns)
  }
  else{
    NLP_names <- updated_data$converted_type$data_field[updated_data$converted_type$data_type == 'Natural Language']
  }

  if(length(ignore.columns) >0 ){
    drop_names <- NLP_names[(column_recog_vector('ignore.columns',NLP_names, updated_data$data) %in% drop_vector)]
    potential_drop_names <- paste(drop_names, ' _other_nominal', sep = '')
    drop_names <- c(drop_names, potential_drop_names)
    NLP_names <- NLP_names[!(column_recog_vector('ignore.columns',NLP_names, updated_data$data) %in% column_recog_vector('ignore.columns',drop_names, updated_data$data))]
  }


  if(length(NLP_names) > 0){
    NLP_data <- updated_data$data %>% dplyr::select(NLP_names)
  }else(stop('No NLP Data present to analyse'))

}
